The controller generator code (iop_control_design_integrator.m) is ready to run, and will import the poleset from "final_poleset.mat".

The Simulink file requires the data file "nested_controller_params.mat" to be loaded into the workspace.
	NOTE: The Simulink block diagram shows two controllers - our final working controller with AND without an integrator, for comparison.